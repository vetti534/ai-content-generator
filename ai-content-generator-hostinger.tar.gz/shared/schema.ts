import { pgTable, text, serial, integer, boolean, jsonb, timestamp, varchar, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export const contentRequests = pgTable("content_requests", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  content: text("content"),
  platform: text("platform").notNull(),
  contentType: text("content_type").notNull(),
  tone: text("tone"),
  category: text("category"),
  language: text("language").default("English"),
  fileUrl: text("file_url"),
  fileName: text("file_name"),
  fileType: text("file_type"),
  generatedContent: jsonb("generated_content"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertContentRequestSchema = createInsertSchema(contentRequests).pick({
  content: true,
  platform: true,
  contentType: true,
  tone: true,
  category: true,
  language: true,
  fileUrl: true,
  fileName: true,
  fileType: true,
});

export type InsertContentRequest = z.infer<typeof insertContentRequestSchema>;
export type ContentRequest = typeof contentRequests.$inferSelect;

// Platform types
export const platformSchema = z.enum([
  "instagram",
  "linkedin", 
  "youtube",
  "twitter",
  "tiktok",
  "facebook"
]);

export const contentTypeSchema = z.enum([
  "video",
  "image", 
  "text"
]);

// Tone options
export const toneSchema = z.enum([
  "professional",
  "casual",
  "funny",
  "motivational",
  "educational",
  "emotional",
  "inspiring",
  "promotional",
  "storytelling",
  "controversial"
]);

// Category options
export const categorySchema = z.enum([
  "business",
  "lifestyle",
  "technology",
  "health",
  "fitness",
  "food",
  "travel",
  "fashion",
  "education",
  "entertainment",
  "news",
  "sports",
  "art",
  "music",
  "gaming",
  "personal"
]);

// Language options
export const languageSchema = z.enum([
  "English",
  "Spanish",
  "French",
  "German",
  "Italian",
  "Portuguese",
  "Russian",
  "Chinese",
  "Japanese",
  "Korean",
  "Arabic",
  "Hindi",
  "Dutch",
  "Swedish",
  "Norwegian"
]);

// AI Generated Content Types
export const aiAnalysisSchema = z.object({
  tone: z.array(z.string()),
  audience: z.string(),
  strategy: z.string(),
});

export const instagramContentSchema = z.object({
  caption: z.string(),
  hashtags: z.array(z.string()),
  description: z.string(),
});

export const linkedinContentSchema = z.object({
  title: z.string(),
  description: z.string(),
  hashtags: z.array(z.string()),
});

export const youtubeContentSchema = z.object({
  title: z.string(),
  description: z.string(),
  tags: z.array(z.string()),
});

export const twitterContentSchema = z.object({
  tweet: z.string(),
  hashtags: z.array(z.string()),
});

export const tiktokContentSchema = z.object({
  caption: z.string(),
  hashtags: z.array(z.string()),
});

export const facebookContentSchema = z.object({
  post: z.string(),
  hashtags: z.array(z.string()),
});

export const generatedContentSchema = z.object({
  analysis: aiAnalysisSchema,
  instagram: instagramContentSchema.optional(),
  linkedin: linkedinContentSchema.optional(),
  youtube: youtubeContentSchema.optional(),
  twitter: twitterContentSchema.optional(),
  tiktok: tiktokContentSchema.optional(),
  facebook: facebookContentSchema.optional(),
});

export type Platform = z.infer<typeof platformSchema>;
export type ContentType = z.infer<typeof contentTypeSchema>;
export type Tone = z.infer<typeof toneSchema>;
export type Category = z.infer<typeof categorySchema>;
export type Language = z.infer<typeof languageSchema>;
export type AIAnalysis = z.infer<typeof aiAnalysisSchema>;
export type GeneratedContent = z.infer<typeof generatedContentSchema>;
